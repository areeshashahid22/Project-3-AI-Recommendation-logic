import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Step 1: Load job roles from CSV
df = pd.read_csv("raw_skills.csv")
job_names = df["job_role"].tolist()
job_skill_texts = df["skills"].tolist()

# Step 2: User input
#user_skills = ["Python", "Cloud Computing", "Automation"]
def recommend_jobs(user_skills):
    user_skill_text = " ".join(user_skills)

# TO verify with different skills:
#user_skills1 = ["Figma", "UI Design", "Prototyping"]

# One more verification:
#user_skills2 = ["Security", "Cryptography", "Ethical Hacking"]

# Step 3: TF-IDF vectorization
    vectorizer = TfidfVectorizer()
    all_texts = job_skill_texts + [user_skill_text]
    tfidf_matrix = vectorizer.fit_transform(all_texts)

    job_vectors = tfidf_matrix[:-1]
    user_vector = tfidf_matrix[-1]

# Step 4: Cosine similarity
    similarity_scores = cosine_similarity(user_vector, job_vectors)
    scores = similarity_scores[0]

# Step 5: Sort and filter to Top 3
    job_score_pairs = list(zip(job_names, scores))
    job_score_pairs.sort(key=lambda pair: pair[1], reverse=True)
    top_3 = job_score_pairs[:3]

    print("Top 3 recommended roles for your skills:", user_skills)
    for job, score in top_3:
        print(f"{job}: {round(score, 3)}")
    print()
    
# Test with 3 different users
user1_skills = ["Python", "Cloud Computing", "Automation"]
user2_skills = ["Figma", "UI Design", "Prototyping"]
user3_skills = ["Security", "Cryptography", "Ethical Hacking"]

recommend_jobs(user1_skills)
recommend_jobs(user2_skills)
recommend_jobs(user3_skills)